from flask import Flask, render_template, json,request
import json
from urllib.request import urlopen
import datetime
from datetime import date
app = Flask(__name__)


# for time and date
import datetime

datetime_object = datetime.datetime.now()
print(datetime_object)

# 


# for stock's data
today = date.today()
_tdate = str(today)
url = 'https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/minute/2020-11-01/"'+_tdate+'"?apiKey=HBSH9Fc30LZbumAvQXssFHbqw8jBgoeEcI3nTe' 
_true_url = url.replace('"', "")
with urlopen(_true_url) as response: 
	source = response.read()
data = json.loads(source)
print(source)
for item in data['results']:
    a = item['v']
    b = item['o']
    c = b,a
    # print(c)
	# print(c)    
# print(main)



	    # return (item['o'])
# chart = {
# "chart": {
# 	"type": "bar",
# 	"title": "Top 5 fruits",
# 	"data": farhan,
# 	"container": "container"
# }
# }
# print(json.dumps(data,indent=2))



# end stock's data



# for tickers data



with urlopen("https://api.polygon.io/v2/reference/tickers?sort=ticker&perpage=1000&page=1&apiKey=WtNA1g_SLvF13nirgjJ8_jaGkEMxowGX") as response:
    source = response.read()
# print(source)
    #     for item in source:
#         print(item)
data_ticker = json.loads(source)
# print(json.dumps(data,indent=2))





# end tickers data


new_data = []
with open('tickers.csv',encoding='utf-8') as csv_file:
    for i in csv_file:
        new_data.append(i)


@app.route("/", methods=['GET', 'POST'])
def main():

	haq = []
	for item in data['results']:
	    a = item['v']
	    b = item['o']
	    haq.append([a,b])
	# ?v=9N6a-VLBa2I&feature=emb_rel_pause
		
	# return render_template('index.html',usman = a,kami = farhan)
# watch
	return render_template("index.html", war = haq)


@app.route('/test1')
def test1():
	haq2 = []
	for item in data['results']:
	    f = item['t']
	    c = item['o']
	    haq2.append([f,c])
	return render_template('researched.html',see = haq2)


@app.route('/test3',methods=['GET','POST'])
def test3():


	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']
	    h = item['h']
	    l = item['l']
	    c = item['c']



	    stock_data.append([t,o,h,l,c])


	print(stock_data)
	tick_data = []    
	for item in data_ticker['tickers']:
		t = item['ticker']
		tick_data.append(t) 
			   
	return render_template('test3.html',usm = stock_data, far = tick_data,new = new_data)





@app.route('/process', methods=['POST'])
def process():
	name = request.form['option']
	a = name.rstrip('\r\n')
	print("checking a vlaue",a)


	today = date.today()
	_tdate = str(today)
	url = 'https://api.polygon.io/v2/aggs/ticker/"'+a+'"/range/1/minute/2020-11-01/"'+_tdate+'"?apiKey=HBSH9Fc30LZbumAvQXssFHbqw8jBgoeEcI3nTe' 
	_true_url = url.replace('"', "")
	with urlopen(_true_url) as response: 
		source = response.read()
	data = json.loads(source)





	_true_url = url.replace('"', "")
	print(_true_url)
	today = date.today()
	_tdate = str(today)
	print(_tdate)
	with urlopen(_true_url) as response: 
		source = response.read()
	data = json.loads(source)

	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']	
	    h = item['h']
	    l = item['l']
	    c = item['c']
	    stock_data.append([t,o,h,l,c])		   
	return render_template('farhan.html',usm = stock_data,new=new_data,ticker = new_data)



@app.route('/farhan')
def farhan():

	today = date.today()
	_tdate = str(today)
	print(_tdate)
	with urlopen("https://api.polygon.io/v2/aggs/ticker/AAPL/range/1/minute/2019-01-01/2020-11-01?apiKey=HBSH9Fc30LZbumAvQXssFHbqw8jBgoeEcI3nTe") as response: 
		source = response.read()
	data = json.loads(source)


	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']
	    h = item['h']
	    l = item['l']
	    c = item['c']
	    stock_data.append([t,o,h,l,c])
	   
	return render_template('farhan.html',usm = stock_data)




@app.route('/chart',methods=['POST'])
def chart():
	name = request.form['option']
	print(name)
		 

	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']
	    h = item['h']
	    l = item['l']
	    c = item['c']
	    stock_data.append([t,o,h,l,c])
		   
	if name == "Heiken Ashi":
		return render_template('heiken.html',far = stock_data,ticker = new_data)
	elif name == "OHLC":
		return render_template("ohlc.html",far = stock_data,ticker = new_data)
	elif name == "Price":
		return render_template("new.html",far = stock_data,ticker = new_data)

	return render_template('new.html',far = stock_data)


@app.route('/new',methods=['GET','POST'])
def new():
	new_data = []
	with open('tickers.csv',encoding='utf-8') as csv_file:
	    for i in csv_file:
	        new_data.append(i)

	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']
	    h = item['h']
	    l = item['l']
	    c = item['c']



	    stock_data.append([t,o,h,l,c])


	tick_data = []    
	for item in data_ticker['tickers']:
		t = item['ticker']
		tick_data.append(t) 
	print(tick_data)		   
	return render_template('new.html',usm = stock_data, far = tick_data,new = new_data)







@app.route('/test4',methods=['GET','POST'])
def test4():
	new_data = []
	with open('tickers.csv',encoding='utf-8') as csv_file:
	    for i in csv_file:
	        new_data.append(i)

	stock_data = []
	for item in data['results']:
	    t = item['t']
	    o = item['o']
	    h = item['h']
	    l = item['l']
	    c = item['c']



	    stock_data.append([t,o,h,l,c])


	print(stock_data)
	tick_data = []    
	for item in data_ticker['tickers']:
		t = item['ticker']
		tick_data.append(t) 
			   
	return render_template('ohlc.html',usm = stock_data, far = tick_data,new = new_data)



















if __name__ == "__main__": 
	app.run()