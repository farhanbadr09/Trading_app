var data = [
  ["January", {{f}} ],
  // ["February", 12000],
  // ["March", 18000],
  // ["April", 11000],
  // ["May", 9000]
];
    
// create a chart
chart = anychart.line();

// create a line series and set the data
var series = chart.line(data);

// set the container id
chart.container("container");

// initiate drawing the chart
chart.draw();